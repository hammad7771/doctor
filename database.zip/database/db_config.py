DB_CONFIG = {
    'host': 'localhost',
    'user': 'Hammad',
    'password': '0000',
    'database': 'doctor_appointment'
}
