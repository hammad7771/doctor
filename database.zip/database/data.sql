CREATE SCHEMA doctor_appointment;
USE doctor_appointment;

CREATE TABLE Hospital (
    Hospital_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Location TEXT
);
CREATE TABLE Patient (
    Patient_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    E_mail VARCHAR(100) UNIQUE,
    Password_Hash VARCHAR(255),
    Phone VARCHAR(15),
    Address TEXT,
    Created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Doctor (
    Doctor_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Specialization VARCHAR(100),
    Phone VARCHAR(15),
    E_mail VARCHAR(100) UNIQUE,
    Hospital_ID INT,
    FOREIGN KEY (Hospital_ID) REFERENCES Hospital(Hospital_ID) ON DELETE CASCADE
);

CREATE TABLE Appointment (
    Appointment_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Doctor_ID INT,
    Appointment_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Status ENUM('Scheduled', 'Completed', 'Cancelled'),
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE,
    FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID) ON DELETE CASCADE
);

 
CREATE TABLE Medical_Record (
    Record_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Doctor_ID INT,
    Diagnosis TEXT,
    Prescription TEXT,
    Record_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE,
    FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID) ON DELETE CASCADE
);

CREATE TABLE Payment (
    Payment_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Amount DECIMAL(15,2),
    Payment_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Status ENUM('Paid', 'Pending', 'Failed'),
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE
);

CREATE TABLE Notifications (
    Notification_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Message TEXT,
    Sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE
);



CREATE TABLE Staff (
    Staff_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Phone VARCHAR(15),
    Position VARCHAR(50),
    E_mail VARCHAR(100) UNIQUE,
    Hospital_ID INT,
    FOREIGN KEY (Hospital_ID) REFERENCES Hospital(Hospital_ID) ON DELETE CASCADE
);

INSERT INTO Hospital (Name, Location) VALUES
('City Hospital', 'Downtown'),
('Green Valley Hospital', 'Green Valley'),
('Sunrise Medical Center', 'East Side'),
('Riverdale Hospital', 'Riverdale'),
('Skyline Clinic', 'Sky Tower'),
('Oakwood Hospital', 'Oakwood Lane'),
('Lakeside Medical', 'Lakeside Drive'),
('Everest Health Center', 'Hilltop'),
('Central Care', 'Main Avenue'),
('Nova Health Clinic', 'Nova City'),
('Pinehill Hospital', 'Pinehill Rd'),
('Metro Medical Center', 'Metro Avenue'),
('Hope Hospital', 'Hope Town'),
('Global Health', 'Global Street'),
('Silverline Hospital', 'Silver Road'),
('Angel Health Center', 'Angel Hill'),
('Unity Hospital', 'Unity Lane'),
('Trinity Medical', 'Trinity Town'),
('Bright Future Clinic', 'Bright City'),
('Harmony Hospital', 'Harmony Block');
select * from hospital;
INSERT INTO Patient (Name, E_mail, Password_Hash, Phone, Address) VALUES
('Alice Smith', 'alice1@example.com', 'hash1', '1234567890', '123 Elm Street'),
('Bob Johnson', 'bob2@example.com', 'hash2', '2345678901', '456 Oak Avenue'),
('Cathy Lee', 'cathy3@example.com', 'hash3', '3456789012', '789 Pine Road'),
('David Brown', 'david4@example.com', 'hash4', '4567890123', '321 Maple Blvd'),
('Eva Wilson', 'eva5@example.com', 'hash5', '5678901234', '654 Cedar Lane'),
('Frank Green', 'frank6@example.com', 'hash6', '6789012345', '987 Birch St'),
('Grace Hall', 'grace7@example.com', 'hash7', '7890123456', '101 Ash Ct'),
('Henry Adams', 'henry8@example.com', 'hash8', '8901234567', '202 Walnut Ave'),
('Isla Young', 'isla9@example.com', 'hash9', '9012345678', '303 Chestnut Blvd'),
('Jake King', 'jake10@example.com', 'hash10', '0123456789', '404 Spruce St'),
('Kara Wright', 'kara11@example.com', 'hash11', '1324354657', '505 Poplar St'),
('Liam Moore', 'liam12@example.com', 'hash12', '2435465768', '606 Cottonwood'),
('Maya Scott', 'maya13@example.com', 'hash13', '3546576879', '707 Redwood Rd'),
('Nina Davis', 'nina14@example.com', 'hash14', '4657687980', '808 Palm Ave'),
('Owen Baker', 'owen15@example.com', 'hash15', '5768798091', '909 Dogwood St'),
('Penny Reed', 'penny16@example.com', 'hash16', '6879809102', '111 Elm Grove'),
('Quinn Ford', 'quinn17@example.com', 'hash17', '7980910213', '222 Oakwood'),
('Ryan Clark', 'ryan18@example.com', 'hash18', '8091021324', '333 Beech Ln'),
('Sara Bell', 'sara19@example.com', 'hash19', '9102132435', '444 Magnolia'),
('Tom Nash', 'tom20@example.com', 'hash20', '1021323546', '555 Sycamore Dr');

select * from patient;
INSERT INTO Doctor (Name, Specialization, Phone, E_mail, Hospital_ID) VALUES
('Dr. Alice Wayne', 'Cardiology', '1010101010', 'dralice@example.com', 1),
('Dr. Ben Carson', 'Neurology', '1111111111', 'drben@example.com', 2),
('Dr. Clara Stone', 'Pediatrics', '1212121212', 'drclara@example.com', 3),
('Dr. Daniel Ross', 'Orthopedics', '1313131313', 'drdaniel@example.com', 4),
('Dr. Emily Cross', 'Dermatology', '1414141414', 'dremily@example.com', 5),
('Dr. Felix Grant', 'Urology', '1515151515', 'drfelix@example.com', 6),
('Dr. Grace Quinn', 'ENT', '1616161616', 'drgrace@example.com', 7),
('Dr. Henry Miles', 'General Physician', '1717171717', 'drhenry@example.com', 8),
('Dr. Irene Paul', 'Gynecology', '1818181818', 'drirene@example.com', 9),
('Dr. Jack Bryan', 'Psychiatry', '1919191919', 'drjack@example.com', 10),
('Dr. Karen Doe', 'Pulmonology', '2020202020', 'drkaren@example.com', 1),
('Dr. Leo Hart', 'Nephrology', '2121212121', 'drleo@example.com', 2),
('Dr. Maria Finch', 'Cardiology', '2222222222', 'drmaria@example.com', 3),
('Dr. Neil Edge', 'Neurology', '2323232323', 'drneil@example.com', 4),
('Dr. Olivia Kent', 'Orthopedics', '2424242424', 'drolivia@example.com', 5),
('Dr. Peter Ray', 'Pediatrics', '2525252525', 'drpeter@example.com', 6),
('Dr. Queenie Star', 'Dermatology', '2626262626', 'drqueenie@example.com', 7),
('Dr. Ryan Bolt', 'ENT', '2727272727', 'drryan@example.com', 8),
('Dr. Sophie Hale', 'Psychiatry', '2828282828', 'drsophie@example.com', 9),
('Dr. Tom Ivy', 'General Physician', '2929292929', 'drtom@example.com', 10);



INSERT INTO Appointment (Patient_ID, Doctor_ID, Appointment_Date, Status) VALUES
(1, 1, NOW(), 'Scheduled'),
(2, 2, NOW(), 'Completed'),
(3, 3, NOW(), 'Scheduled'),
(4, 4, NOW(), 'Cancelled'),
(5, 5, NOW(), 'Scheduled'),
(6, 6, NOW(), 'Completed'),
(7, 7, NOW(), 'Scheduled'),
(8, 8, NOW(), 'Cancelled'),
(9, 9, NOW(), 'Scheduled'),
(10, 10, NOW(), 'Scheduled'),
(11, 11, NOW(), 'Completed'),
(12, 12, NOW(), 'Scheduled'),
(13, 13, NOW(), 'Scheduled'),
(14, 14, NOW(), 'Cancelled'),
(15, 15, NOW(), 'Scheduled'),
(16, 16, NOW(), 'Completed'),
(17, 17, NOW(), 'Scheduled'),
(18, 18, NOW(), 'Cancelled'),
(19, 19, NOW(), 'Scheduled'),
(20, 20, NOW(), 'Scheduled');
select * from appointment;
INSERT INTO Medical_Record (Patient_ID, Doctor_ID, Diagnosis, Prescription) VALUES
(1, 1, 'Common Cold', 'Rest + Fluids'),
(2, 2, 'Headache', 'Ibuprofen 400mg'),
(3, 3, 'Allergy', 'Antihistamine'),
(4, 4, 'Back Pain', 'Paracetamol'),
(5, 5, 'Infection', 'Antibiotics'),
(6, 6, 'Asthma', 'Inhaler'),
(7, 7, 'Skin Rash', 'Ointment'),
(8, 8, 'Diabetes', 'Insulin'),
(9, 9, 'Anxiety', 'Therapy'),
(10, 10, 'Fever', 'Paracetamol'),
(11, 11, 'Sore Throat', 'Lozenges'),
(12, 12, 'High BP', 'Beta Blockers'),
(13, 13, 'Arthritis', 'NSAIDs'),
(14, 14, 'Flu', 'Rest + Medication'),
(15, 15, 'Migraine', 'Pain Relievers'),
(16, 16, 'Depression', 'Therapy'),
(17, 17, 'UTI', 'Antibiotics'),
(18, 18, 'Gastritis', 'Antacids'),
(19, 19, 'Eye Strain', 'Eye Drops'),
(20, 20, 'Low BP', 'Hydration');
INSERT INTO Payment (Patient_ID, Amount, Status) VALUES
(1, 500.00, 'Paid'),
(2, 300.00, 'Pending'),
(3, 450.00, 'Paid'),
(4, 200.00, 'Failed'),
(5, 600.00, 'Paid'),
(6, 250.00, 'Pending'),
(7, 150.00, 'Paid'),
(8, 400.00, 'Paid'),
(9, 350.00, 'Failed'),
(10, 100.00, 'Pending'),
(11, 500.00, 'Paid'),
(12, 200.00, 'Paid'),
(13, 450.00, 'Pending'),
(14, 300.00, 'Paid'),
(15, 250.00, 'Failed'),
(16, 600.00, 'Paid'),
(17, 350.00, 'Pending'),
(18, 400.00, 'Paid'),
(19, 100.00, 'Paid'),
(20, 700.00, 'Paid');
INSERT INTO Notifications (Patient_ID, Message) VALUES
(1, 'Appointment confirmed for tomorrow.'),
(2, 'Doctor has uploaded a new record.'),
(3, 'Your payment is pending.'),
(4, 'Prescription ready for pickup.'),
(5, 'Appointment has been cancelled.'),
(6, 'Reminder: visit scheduled today.'),
(7, 'Medical report uploaded.'),
(8, 'Doctor sent you a message.'),
(9, 'Appointment rescheduled.'),
(10, 'Payment received.'),
(11, 'Lab results are available.'),
(12, 'Your appointment is completed.'),
(13, 'Feedback requested.'),
(14, 'New message from doctor.'),
(15, 'Insurance claim processed.'),
(16, 'New test results uploaded.'),
(17, 'Doctor changed appointment date.'),
(18, 'Your account has been updated.'),
(19, 'Medical advice updated.'),
(20, 'Thank you for visiting us.');
INSERT INTO Staff (Name, Phone, Position, E_mail, Hospital_ID) VALUES
('Anna Bell', '7000000001', 'Receptionist', 'anna1@hospital.com', 1),
('Brian Lane', '7000000002', 'Nurse', 'brian2@hospital.com', 2),
('Cara Dean', '7000000003', 'Lab Tech', 'cara3@hospital.com', 3),
('Dean West', '7000000004', 'Janitor', 'dean4@hospital.com', 4),
('Ella Rose', '7000000005', 'Receptionist', 'ella5@hospital.com', 5),
('Fred Lane', '7000000006', 'Admin', 'fred6@hospital.com', 6),
('Gina Paul', '7000000007', 'Pharmacist', 'gina7@hospital.com', 7),
('Harry Miles', '7000000008', 'Nurse', 'harry8@hospital.com', 8),
('Ivy Jones', '7000000009', 'Receptionist', 'ivy9@hospital.com', 9),
('Jack Cole', '7000000010', 'Janitor', 'jack10@hospital.com', 10),
('Kira Blue', '7000000011', 'Nurse', 'kira11@hospital.com', 1),
('Liam Stone', '7000000012', 'Receptionist', 'liam12@hospital.com', 2),
('Mona Lee', '7000000013', 'Admin', 'mona13@hospital.com', 3),
('Nate Hill', '7000000014', 'Pharmacist', 'nate14@hospital.com', 4),
('Olga Hunt', '7000000015', 'Receptionist', 'olga15@hospital.com', 5),
('Paul Gill', '7000000016', 'Lab Tech', 'paul16@hospital.com', 6),
('Quinn Ray', '7000000017', 'Admin', 'quinn17@hospital.com', 7),
('Rita Watts', '7000000018', 'Nurse', 'rita18@hospital.com', 8),
('Sam Bell', '7000000019', 'Pharmacist', 'sam19@hospital.com', 9),
('Tina Best', '7000000020', 'Receptionist', 'tina20@hospital.com', 10);

select * from hospital;

SELECT   Appointment.Appointment_ID,
    Patient.Name AS Patient_Name,
    Doctor.Name AS Doctor_Name,
    Doctor.Specialization,
    Appointment.Appointment_Date,
    Appointment.Status
FROM Appointment
JOIN Patient ON Appointment.Patient_ID = Patient.Patient_ID
JOIN Doctor ON Appointment.Doctor_ID = Doctor.Doctor_ID;

-- SELECT Name 
-- FROM Doctor 
-- WHERE Doctor_ID NOT IN (
--     SELECT DISTINCT Doctor_ID FROM Appointment
-- );


SELECT 
    patient.Name,
    SUM(payment.Amount) AS Total_Paid
FROM Patient 
JOIN Payment ON patient.Patient_ID = payment.Patient_ID
WHERE payment.Status = 'Paid'
GROUP BY patient.Patient_ID;


SELECT Name,patient_id
FROM Patient
WHERE Patient_ID = (
    SELECT Patient_ID 
    FROM Appointment 
    GROUP BY Patient_ID 
    ORDER BY COUNT(*) DESC 
    LIMIT 1
);

SELECT Name 
FROM Patient 
WHERE Patient_ID NOT IN (
    SELECT DISTINCT Patient_ID FROM Payment WHERE Status = 'Paid'
);



