import mysql.connector

# Database connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="0000",
    database="doctor_appointment"
)

cursor = conn.cursor()

# Add data to Hospital table
def add_data_to_hospital():
    cursor.execute("INSERT INTO Hospital (Name, Location) VALUES('City Hospital', 'Downtown');")
    conn.commit()
    print("Data inserted into Hospital.")

    cursor.execute("SELECT * FROM Hospital;")
    myresult = cursor.fetchall()
    for x in myresult:
        print(x)

# Read data from Hospital table
def read_data_from_hospital():
    cursor.execute("SELECT * FROM Hospital;")
    myresult = cursor.fetchall()
    print("Hospital Table Data:")
    for x in myresult:
        print(x)

# Add data to Appointment table
def add_appointment_data():
    cursor.execute("INSERT INTO Appointment (Patient_ID, Doctor_ID, Appointment_Date, Status) VALUES(1, 1, NOW(), 'Scheduled');")
    conn.commit()
    print("Data inserted into Appointment.")

    cursor.execute("SELECT * FROM Appointment;")
    myresult = cursor.fetchall()
    for x in myresult:
        print(x)

# Read data from Appointment table
def read_appointment_data():
    cursor.execute("SELECT * FROM Appointment;")
    myresult = cursor.fetchall()
    print("Appointment Table Data:")
    for x in myresult:
        print(x)
        
    

def all_doctor_patient_app():
    cursor.execute("SELECT Appointment.Appointment_ID,Patient.Name AS Patient_Name,Doctor.Name AS Doctor_Name,Doctor.Specialization,Appointment.Appointment_Date,Appointment.Status FROM Appointment JOIN Patient ON Appointment.Patient_ID = Patient.Patient_ID JOIN Doctor ON Appointment.Doctor_ID = Doctor.Doctor_ID;")
    print('fetched')
    return cursor.fetchall()
   
def patient_paid():
    cursor.execute("""
        SELECT patient.Name, SUM(payment.Amount) AS Total_Paid
        FROM Patient 
        JOIN Payment ON patient.Patient_ID = payment.Patient_ID
        WHERE payment.Status = 'Paid'
        GROUP BY patient.Patient_ID;
    """)
    return cursor.fetchall()

def patient_with_most_app():
    cursor.execute("""
        SELECT Name, patient_id
        FROM Patient
        WHERE Patient_ID = (
            SELECT Patient_ID 
            FROM Appointment 
            GROUP BY Patient_ID 
            ORDER BY COUNT(*) DESC 
            LIMIT 1
        );
    """)
    return cursor.fetchall()

def patient_unpaid():
    cursor.execute("""
        SELECT Name 
        FROM Patient 
        WHERE Patient_ID NOT IN (
            SELECT DISTINCT Patient_ID FROM Payment WHERE Status = 'Paid'
        );
    """)
    return cursor.fetchall()
