from flask import Flask, render_template, request, jsonify
import mysql.connector
from database import read_appointment_data, add_appointment_data,read_data_from_hospital, add_data_to_hospital,all_doctor_patient_app,patient_paid,patient_unpaid,patient_with_most_app
app = Flask(__name__)
import database 

# Database connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="0000",
    database="doctor_appointment"
)


cursor = conn.cursor()

@app.route('/')
def index():

    return render_template('index.html')


# for patient doctor app
@app.route("/doctor-patient-appointments")
def doctor_patient_appointments():
    rows = all_doctor_patient_app()
    headers = ["Appointment_ID", "Patient_Name", "Doctor_Name", "Specialization", "Appointment_Date", "Status"]
    return render_template("custom_query_template.html", headers=headers, rows=rows)


# for paid patient
@app.route("/paid-patients")
def view_patient_paid():
    rows = patient_paid()
    headers = ["Name"]
    return render_template("custom_query_template.html", headers=headers, rows=rows)


# for more patient with appo


@app.route("/most-appointments")
def view_most_appointments():
    rows = patient_with_most_app()
    headers = ["Name", "Patient_ID"]
    return render_template("custom_query_template.html", headers=headers, rows=rows)


@app.route("/unpaid-patients")
def view_unpaid_patients():
    rows = patient_unpaid()
    headers = ["Name"]
    return render_template("custom_query_template.html", headers=headers, rows=rows)


@app.route("/table/<int:table_id>")
def table_view(table_id):
    cursor = database.conn.cursor()
    if table_id == 1:
        cursor.execute("SELECT * FROM Hospital")
        headers = ["Hospital_ID", "Name", "Location"]
    elif table_id == 2:
        cursor.execute("SELECT * FROM Doctor")
        headers = ["Doctor_ID", "Name", "Specialization", "Phone", "Email", "Hospital_ID"]
    elif table_id == 3:
        cursor.execute("SELECT * FROM Appointment")
        headers = ["Appointment_ID", "Patient_ID", "Doctor_ID", "Appointment_Date", "Status"]
    elif table_id == 4:
        cursor.execute("SELECT * FROM Patient")
        headers = ["Patient_ID", "Name", "Email", "Phone", "Address", "Created_at"]
        
    elif table_id == 5:
        cursor.execute("SELECT * FROM Payment")
        headers = ["Payment_ID", "Patient_ID", "Amount", "Payment_Date", "Status"]
    elif table_id == 6:
        cursor.execute("SELECT * FROM Notifications")
        headers = ["Notification_ID", "Patient_ID", "Message", "Sent_at"]
    elif table_id == 7:
        cursor.execute("SELECT * FROM Medical_Record")
        headers = ["Record_ID", "Patient_ID", "Doctor_ID", "Diagnosis", "Prescription", "Record_Date"]
    elif table_id == 8:
        cursor.execute("SELECT * FROM Staff")
        headers = ["Staff_ID", "Name", "Phone", "Position", "Email", "Hospital_ID"]
    else:
        return "<p>Invalid Table</p>"

    rows = cursor.fetchall()
    return render_template("table_template.html", headers=headers, rows=rows)


if __name__ == '__main__':
    app.run(debug=True)
