  const pagesContainer = document.getElementById("pages");
  tablesData.forEach((_, i) => {
    pagesContainer.appendChild(createTable(i));
  });

  function showPage(num) {
    const pages = document.querySelectorAll(".page");
    pages.forEach((page, index) => {
      page.classList.toggle("active", index === num - 1);
    });
  }

  function addRow(index) {
    const table = document.querySelector(`#table${index}`);
    const cols = table.rows[0].cells.length;
    const newRow = table.insertRow();
    for (let i = 0; i < cols; i++) {
      const newCell = newRow.insertCell(i);
      newCell.innerText = prompt(`Enter value for column ${i + 1}`) || "";
    }
  }

 
function loadTable(tableName) {
  fetch(`/get_table/${tableName}`)
    .then(res => res.json())
    .then(data => {
      const table = document.getElementById("my-table");
      table.innerHTML = "";
      data.forEach(row => {
        const tr = document.createElement("tr");
        row.forEach(cell => {
          const td = document.createElement("td");
          td.textContent = cell;
          tr.appendChild(td);
        });
        table.appendChild(tr);
      });
    });
}
function showPage(pageNumber) {
  fetch(`/table/${pageNumber}`)
    .then(response => response.text())
    .then(html => {
      document.getElementById("pages").innerHTML = html;
    });
}


